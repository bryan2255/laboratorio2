package com.example.spinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView tv_respuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tv_respuesta = (TextView)findViewById(R.id.txt_respuesta);
        spinner = (Spinner)findViewById(R.id.spinner);

        String [] respuestas = {"pc gamer", "consola", "celular", "nintendo switch"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>( this, android.R.layout.simple_spinner_item, respuestas);
        spinner.setAdapter(adapter);
    }
    public void mostrar(View view){
        String seleccionado = spinner.getSelectedItem().toString();
        if (seleccionado.equals("pc gamer")){
            tv_respuesta.setText("tienes buenos gustos");
        }else if (seleccionado.equals("consola")) {
            tv_respuesta.setText("muy buena opcion");
        }else if (seleccionado.equals("celular")) {
            tv_respuesta.setText("existen mejores opciones");
        }else if (seleccionado.equals("nintendo switch")) {
            tv_respuesta.setText("buena opcion");
        }
    }
}